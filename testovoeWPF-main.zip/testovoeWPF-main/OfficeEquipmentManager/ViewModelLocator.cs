﻿using Microsoft.Extensions.DependencyInjection;
using OfficeEquipmentManager.ViewModel;

namespace OfficeEquipmentManager
{
    public class ViewModelLocator
    {
        public EquipmentViewModel? EquipmentViewModel
            => App.ServiceProvider?.GetService<EquipmentViewModel>();
    }
}