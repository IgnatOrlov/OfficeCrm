﻿namespace OfficeEquipmentManager.Model
{
    public class Equipment
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public EquipmentType Type { get; set; }
        public EquipmentStatus Status { get; set; }
    }

    public enum EquipmentType
    {
        Printer,
        Scanner,
        Monitor
    }

    public enum EquipmentStatus
    {
        InUse,
        InStock,
        InRepair
    }
}