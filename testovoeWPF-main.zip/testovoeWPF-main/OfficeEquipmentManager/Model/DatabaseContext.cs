﻿using Microsoft.EntityFrameworkCore;

namespace OfficeEquipmentManager.Model
{
    public class DatabaseContext : DbContext
    {
        public DatabaseContext(DbContextOptions<DatabaseContext> options) : base(options) { }

        public DbSet<Equipment> Equipments { get; set; } = null!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Equipment>().HasData(
                new Equipment { Id = 1, Name = "HP LaserJet Pro", Type = EquipmentType.Printer, Status = EquipmentStatus.InUse },
                new Equipment { Id = 2, Name = "Epson Perfection V39", Type = EquipmentType.Scanner, Status = EquipmentStatus.InStock },
                new Equipment { Id = 3, Name = "Dell UltraSharp 27\"", Type = EquipmentType.Monitor, Status = EquipmentStatus.InRepair }
            );
        }
    }
}