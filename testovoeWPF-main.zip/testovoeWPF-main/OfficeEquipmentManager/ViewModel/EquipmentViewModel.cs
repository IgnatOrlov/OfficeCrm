﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using OfficeEquipmentManager.Model;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace OfficeEquipmentManager.ViewModel
{
    public partial class EquipmentViewModel : ObservableValidator
    {
        private readonly DatabaseContext _dbContext;

        [ObservableProperty]
        private ObservableCollection<Equipment> _equipments = new();

        [ObservableProperty]
        [NotifyCanExecuteChangedFor(nameof(AddEquipmentCommand))]
        [NotifyCanExecuteChangedFor(nameof(UpdateEquipmentCommand))]
        [NotifyCanExecuteChangedFor(nameof(DeleteEquipmentCommand))]
        private Equipment? _selectedEquipment;

        [ObservableProperty]
        [NotifyDataErrorInfo]
        [Required(ErrorMessage = "Name is required")]
        private string _name = string.Empty;

        [ObservableProperty]
        private EquipmentType _type = EquipmentType.Printer;

        [ObservableProperty]
        private EquipmentStatus _status = EquipmentStatus.InStock;

        public EquipmentViewModel(DatabaseContext dbContext)
        {
            _dbContext = dbContext;
            LoadEquipments();
        }

        private void LoadEquipments()
        {
            Equipments = new ObservableCollection<Equipment>(_dbContext.Equipments.ToList());
        }

        [RelayCommand(CanExecute = nameof(CanAddEquipment))]
        private void AddEquipment()
        {
            ValidateAllProperties();
            if (HasErrors) return;

            var equipment = new Equipment
            {
                Name = Name,
                Type = Type,
                Status = Status
            };

            _dbContext.Equipments.Add(equipment);
            _dbContext.SaveChanges();
            LoadEquipments();
            ClearFields();
        }

        private bool CanAddEquipment() => !string.IsNullOrWhiteSpace(Name);

        [RelayCommand(CanExecute = nameof(IsEquipmentSelected))]
        private void UpdateEquipment()
        {
            if (SelectedEquipment == null) return;

            SelectedEquipment.Name = Name;
            SelectedEquipment.Type = Type;
            SelectedEquipment.Status = Status;

            _dbContext.Equipments.Update(SelectedEquipment);
            _dbContext.SaveChanges();
            LoadEquipments();
        }

        private bool IsEquipmentSelected() => SelectedEquipment != null;

        [RelayCommand(CanExecute = nameof(IsEquipmentSelected))]
        private void DeleteEquipment()
        {
            if (SelectedEquipment == null) return;

            _dbContext.Equipments.Remove(SelectedEquipment);
            _dbContext.SaveChanges();
            LoadEquipments();
            ClearFields();
        }

        [RelayCommand]
        private void ClearFields()
        {
            Name = string.Empty;
            Type = EquipmentType.Printer;
            Status = EquipmentStatus.InStock;
            SelectedEquipment = null;
        }

        partial void OnSelectedEquipmentChanged(Equipment? value)
        {
            if (value == null) return;

            Name = value.Name;
            Type = value.Type;
            Status = value.Status;
        }
    }
}